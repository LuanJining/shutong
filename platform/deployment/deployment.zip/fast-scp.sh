zip -r deployment.zip ./
scp deployment.zip root@182.140.132.5:/root/deployment.zip
rm -f deployment.zip